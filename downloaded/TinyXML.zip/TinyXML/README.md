TinyXML Library for Arduino
----

Forked from Adam Rudd's (adamvr) 'arduino-sketches' repository:
https://github.com/adamvr/arduino-sketches
Just the TinyXML library is used here, updated for current Arduino IDE.
